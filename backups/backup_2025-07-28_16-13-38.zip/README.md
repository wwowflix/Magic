\# ⚡ MAGIC – Modular AI Growth \& Intelligence Core



\## 📁 Folder Structure

MAGIC/

├── scripts/

│ ├── phase0/

│ ├── phase1/

│ ├── inbox/

├── outputs/

│ ├── data/

│ ├── trends/

├── docs/

├── logs/

├── venv/









\## ✅ Setup Steps



1\. Create folder tree with `setup\_folders.py`

2\. Sort files using File Juggler

3\. Follow naming rules in `docs/naming.md`



\## 📄 File Naming System

See: `docs/naming.md`



