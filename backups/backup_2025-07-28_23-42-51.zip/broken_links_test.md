Here’s a bad link: \[404 Example](http://example.com/thispagedoesnotexist)



Here’s a missing image: !\[Missing](images/fake.png)



Here’s a working one: \[Google](https://www.google.com)



