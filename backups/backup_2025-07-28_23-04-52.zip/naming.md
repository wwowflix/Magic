\# 📂 MAGIC Project – Naming Conventions



\## ✅ Filename Format





\### Examples

\- `00A\_define\_folder\_structure\_READY.py`

\- `01B\_project\_folder\_creator\_READY.py`

\- `02F\_trend\_lifecycle\_tagger\_READY.py`



\## 🧩 Rule Explanation:

\- `00`, `01`, `02` = Phase number

\- `A`, `B`, `C` = Module inside phase

\- `snake\_case` name = Describes the feature

\- `\_READY.py` = Means the script is live + tested





\# 📛 MAGIC Project File Naming Convention



To ensure automation and phase-based sorting works smoothly, all files must follow the format:





\## ✅ Examples



\- `00A\_define\_folder\_structure\_READY.py`

\- `01C\_test\_scaffolds\_for\_scrapers\_READY.py`

\- `05G\_thumbnail\_auto\_generator\_READY.py`



\## 💡 Guidelines



\- Always start with 2-digit \*\*Phase Number\*\* (e.g., `00`, `01`, `12`)

\- Use 1 capital \*\*Module Letter\*\* (A–Z)

\- Underscore (`\_`) as separator

\- End with `\_READY.py` to trigger automation

\- Use only safe characters: `\[a-zA-Z0-9\_()+\\- ]`



\## ❌ Bad Examples



\- `define-folder-structure.py` ❌ No phase/module or suffix

\- `01C\_script\_FINAL.py` ❌ Wrong suffix

\- `1c\_script\_ready.py` ❌ Lowercase + invalid format



---



\*\*Stick to the format for full compatibility with File Juggler and automation rules.\*\*





